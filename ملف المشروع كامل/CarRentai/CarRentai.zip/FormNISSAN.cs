﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CarRentai
{
    public partial class FormNISSAN : Form
    {
        private FormTypes _typesForm;

        public FormNISSAN()
        {
            InitializeComponent();
        }

        public FormNISSAN(FormTypes typesForm) : this()
        {
            _typesForm = typesForm;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (_typesForm != null)
            {
                _typesForm.Show();
            }

            this.Hide();
        }

        private void FormNISSAN_Load(object sender, EventArgs e)
        {

        }

        // =============== دالة إضافة الحجز ===============
       

        private void AddBooking(string carName)
        {
            string connStr = @"Data Source=(LocalDB)\MSSQLLocalDB;
                   AttachDbFilename=D:\Mohammed Mustafa\A\CarRentai\CarRentai\CarRentalBD.mdf;
                   Integrated Security=True;Connect Timeout=30";
            using (SqlConnection con = new SqlConnection(connStr))
            {
                con.Open();

                string queryCar = "SELECT CarID, RentPrice FROM Cars WHERE Name = @Name";
                SqlCommand cmdCar = new SqlCommand(queryCar, con);
                cmdCar.Parameters.AddWithValue("@Name", carName);

                SqlDataReader reader = cmdCar.ExecuteReader();

                if (reader.Read())
                {
                    int carID = (int)reader["CarID"];
                    decimal price = (decimal)reader["RentPrice"];
                    reader.Close();

                    string insertBooking = "INSERT INTO Bookings (CarID, Price) VALUES (@CarID, @Price)";
                    SqlCommand cmdBooking = new SqlCommand(insertBooking, con);
                    cmdBooking.Parameters.AddWithValue("@CarID", carID);
                    cmdBooking.Parameters.AddWithValue("@Price", price);
                    cmdBooking.ExecuteNonQuery();

                    MessageBox.Show("✔ تم حجز السيارة بنجاح!");

                    // فتح الفورم لعرض جميع الحجوزات
                    FormBookings bookingsForm = new FormBookings();
                    bookingsForm.ShowDialog();
                }
            }
        }
        

        // =============== أزرار الحجز ===============
        private void btnALTIMA_Click(object sender, EventArgs e)
        {
            AddBooking("ALTIMA");
        }

        private void btnSENTRA_Click(object sender, EventArgs e)
        {
            AddBooking("SENTRA");
        }

        private void btnKICKS_Click(object sender, EventArgs e)
        {
            AddBooking("KICKS");
        }
    }
}